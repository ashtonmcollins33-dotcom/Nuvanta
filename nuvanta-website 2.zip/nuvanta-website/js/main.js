const R=[[/ship|international|deliver/i,"Thanks for asking! Yes, we ship to most countries. Delivery usually takes 5–10 business days, and customs fees may apply. Tell me your country and I can confirm."],
[/return|refund|exchange/i,"Sorry the order wasn't right! Unopened bags can be returned within 30 days. Opened bags are reviewed case by case. Could you share your order number?"],
[/appoint|book|3pm|friday|slot|available/i,"Thanks for reaching out! Friday at 3pm looks possible. I'll hold it once the owner confirms, and you'll get a confirmation shortly."],
[/cold brew|bean|roast|recommend/i,"For cold brew, a medium-dark roast with chocolate notes works well, and a coarse grind is best. Want a few options from our catalog?"]];
const out=document.getElementById('dout');
function draft(q){q=q.trim();if(!q)return;const m=R.find(r=>r[0].test(q));
out.textContent='';const p=document.createElement('p');p.textContent=m?m[1]:"Thanks for your message! I don't have approved information to answer that, so I'm flagging it for the owner to reply personally.";
const s=document.createElement('small');s.textContent=(m?'Draft reply — waiting for owner approval.':'No matching approved information — escalated to a human.')+' (Simulated example)';
p.style.margin=0;out.append(p,s)}
document.querySelectorAll('.chip').forEach(c=>c.onclick=()=>{dq.value=c.textContent;draft(c.textContent)});
dform.onsubmit=e=>{e.preventDefault();draft(dq.value)};
aform.onsubmit=async e=>{e.preventDefault();ast.hidden=false;
if(!an.value.trim()||!/^\S+@\S+\.\S+$/.test(ae.value)){ast.textContent="Please enter your name and a valid email.";return}
abtn.disabled=true;ast.textContent="Sending...";
try{const r=await fetch('/api/early-access',{method:'POST',headers:{'Content-Type':'application/json'},
body:JSON.stringify({name:an.value,email:ae.value,type:at.value,message:am.value,website:aw.value})});
if(r.ok){ast.textContent="Thank you! We received your request and will email you.";aform.reset()}
else if(r.status===503){ast.textContent="Sign-ups are not switched on yet. Please try again soon."}
else if(r.status===400){ast.textContent="Please check your name and email and try again."}
else{ast.textContent="Something went wrong. Please try again later."}
}catch(err){ast.textContent="Could not reach the server. If you are viewing this as a local file, the form only works on the published site."}
abtn.disabled=false};
menu.onclick=()=>{const o=links.classList.toggle('open');menu.setAttribute('aria-expanded',o)};
links.onclick=()=>{links.classList.remove('open');menu.setAttribute('aria-expanded',false)};
const io=new IntersectionObserver(es=>es.forEach(x=>{if(x.isIntersecting){x.target.classList.add('in');io.unobserve(x.target)}}),{threshold:.15});
document.querySelectorAll('.reveal').forEach(el=>io.observe(el));
