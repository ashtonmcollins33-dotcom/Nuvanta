// Vercel serverless function: receives the early-access form and emails it to the founder via Resend.
// Needs two environment variables set in Vercel: RESEND_API_KEY and NOTIFY_EMAIL.
const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const hits = new Map(); // very simple per-instance rate limit

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const b = typeof req.body === 'string' ? JSON.parse(req.body || '{}') : (req.body || {});
  if (b.website) return res.status(200).json({ ok: true }); // honeypot: bots fill this in

  const ip = (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || 'unknown';
  const now = Date.now();
  const recent = (hits.get(ip) || []).filter(t => now - t < 600000);
  if (recent.length >= 5) return res.status(429).json({ error: 'Too many requests' });
  hits.set(ip, [...recent, now]);

  const name = String(b.name || '').trim().slice(0, 100);
  const email = String(b.email || '').trim().slice(0, 200);
  const type = String(b.type || '').slice(0, 50);
  const message = String(b.message || '').trim().slice(0, 1000);
  if (!name || !/^\S+@\S+\.\S+$/.test(email)) return res.status(400).json({ error: 'Invalid input' });

  const key = process.env.RESEND_API_KEY, to = process.env.NOTIFY_EMAIL;
  if (!key || !to) return res.status(503).json({ error: 'Not configured' });

  try {
    const r = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        from: process.env.FROM_EMAIL || 'Nuvanta <onboarding@resend.dev>',
        to: [to],
        reply_to: email,
        subject: `New Nuvanta early-access request: ${name.replace(/[\r\n]/g, ' ')}`,
        html: `<p><b>Name:</b> ${esc(name)}</p><p><b>Email:</b> ${esc(email)}</p><p><b>Business type:</b> ${esc(type)}</p><p><b>Message:</b><br>${esc(message) || '(none)'}</p>`
      })
    });
    if (!r.ok) return res.status(502).json({ error: 'Email service error' });
    return res.status(200).json({ ok: true });
  } catch (e) {
    return res.status(502).json({ error: 'Email service error' });
  }
};
