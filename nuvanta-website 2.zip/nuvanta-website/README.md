# Nuvanta Website

Static site (plain HTML, CSS, JavaScript) plus one small serverless function that receives early-access sign-ups. Nothing to install.

## Files
- `index.html`, `privacy.html`, `terms.html` – the pages
- `css/styles.css`, `js/main.js` – styling, demo, form, menu
- `api/early-access.js` – receives the form and emails it to you (via Resend)
- `vercel.json`, `package.json`, `.gitignore`, `.env.example`, `robots.txt`, `favicon.svg`

## Look at it on your computer
Double-click `index.html`. The form will not work this way (it needs the published site), but everything else does.

## Publish (GitHub + Vercel)
1. GitHub: create an empty repository `nuvanta-website`, then use "uploading an existing file" to drag in everything (including the `api`, `css`, `js` folders) and commit.
2. Vercel: sign in with GitHub, **Add New > Project**, import the repository, leave settings alone, **Deploy**.

## Make the sign-up form work (about 10 minutes)
1. Create a free account at https://resend.com, sign up using the email address where you want to receive sign-ups.
2. In Resend, open **API Keys** and create a key. Copy it.
3. In Vercel open your project > **Settings > Environment Variables** and add:
   - `RESEND_API_KEY` = the key you copied
   - `NOTIFY_EMAIL` = the same email you signed up to Resend with
4. In Vercel open **Deployments**, click the latest one, and choose **Redeploy** so it picks up the new settings.
5. Open your live site, submit the form, and check your inbox (and spam folder).

Until step 3 is done the form tells visitors "Sign-ups are not switched on yet". Never put the key in any file you upload to GitHub.

Note: with Resend's free starter sender you can only receive emails at the address you signed up with. To email other people from your own address later, verify your domain in Resend.

## Before you promote the site
- Have a lawyer review `privacy.html` and `terms.html` (they are plain-language drafts).
- The demo is a simulation, pricing is proposed, and the product is not built yet. The site says so; keep those labels until they are true.
- Optional: buy a domain (about $10-15/year) and attach it in Vercel > Settings > Domains.
